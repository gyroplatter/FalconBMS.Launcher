﻿using FalconBMS.Launcher.Models;
using FalconBMS.Launcher.Services;
using FalconBMS.Launcher.ViewModels;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Threading;

namespace FalconBMS.Launcher.Views;

public partial class DevicesView : UserControl
{
    private readonly LiveDeviceButtonStateService
        _deviceButtonPolling = new();

    private DispatcherTimer? _timer;

    private DevicesViewModel?
        _subscribedViewModel;

    public DevicesView()
    {
        InitializeComponent();

        _deviceButtonPolling.ButtonStateChanged +=
            DeviceButtonPolling_ButtonStateChanged;

        Loaded += DevicesView_Loaded;

        Unloaded += DevicesView_Unloaded;

        DataContextChanged +=
            DevicesView_DataContextChanged;
    }

    private void DevicesView_Loaded(
        object sender,
        RoutedEventArgs e)
    {
        SubscribeToViewModel(
            DataContext as DevicesViewModel);

        StartLiveDevicePolling();
    }

    private void DevicesView_Unloaded(
        object sender,
        RoutedEventArgs e)
    {
        StopLiveDevicePolling();

        SubscribeToViewModel(null);
    }

    private void DevicesView_DataContextChanged(
        object sender,
        DependencyPropertyChangedEventArgs e)
    {
        SubscribeToViewModel(
            e.NewValue as DevicesViewModel);
    }

    private void SubscribeToViewModel(
        DevicesViewModel? viewModel)
    {
        if (ReferenceEquals(
                _subscribedViewModel,
                viewModel))
        {
            return;
        }

        if (_subscribedViewModel is not null)
        {
            _subscribedViewModel.KeyMappingRequested -=
                DevicesViewModel_KeyMappingRequested;

            _subscribedViewModel.DeviceMapEditorRequested -=
                DevicesViewModel_DeviceMapEditorRequested;
        }

        _subscribedViewModel = viewModel;

        if (_subscribedViewModel is not null)
        {
            _subscribedViewModel.KeyMappingRequested +=
                DevicesViewModel_KeyMappingRequested;

            _subscribedViewModel.DeviceMapEditorRequested +=
                DevicesViewModel_DeviceMapEditorRequested;
        }
    }

    private void StartLiveDevicePolling()
    {
        StopLiveDevicePolling();

        _timer =
            new DispatcherTimer(
                DispatcherPriority.Background)
            {
                Interval =
                    TimeSpan.FromMilliseconds(30)
            };

        _timer.Tick += Timer_Tick;
        _timer.Start();
    }

    private void StopLiveDevicePolling()
    {
        if (_timer is not null)
        {
            _timer.Stop();
            _timer.Tick -= Timer_Tick;
            _timer = null;
        }

        _deviceButtonPolling.Reset();
    }

    private void Timer_Tick(
        object? sender,
        EventArgs e)
    {
        if (DataContext
            is not DevicesViewModel viewModel)
        {
            return;
        }

        DeviceBindingProfile[] connectedDevices =
            viewModel.Devices
                .Select(
                    device =>
                        device.DeviceProfile)
                .Where(
                    device =>
                        device.IsConnected)
                .ToArray();

        if (connectedDevices.Length == 0)
            return;

        Window? window =
            Window.GetWindow(this);

        if (window is null)
            return;

        IntPtr hwnd =
            new WindowInteropHelper(window)
                .Handle;

        if (hwnd == IntPtr.Zero)
            return;

        // Device View follows whichever connected
        // device the user physically presses.
        _deviceButtonPolling.Poll(
            connectedDevices,
            hwnd);
    }

    private void DeviceButtonPolling_ButtonStateChanged(
        object? sender,
        LiveDeviceButtonStateChangedEventArgs e)
    {
        if (!e.IsPressed)
            return;

        if (DataContext
            is not DevicesViewModel viewModel)
        {
            return;
        }

        viewModel.HandleButtonPressed(
            e.DurableDeviceKey,
            e.ButtonIndex);
    }

    private void DevicesViewModel_DeviceMapEditorRequested(
        object? sender,
        DeviceMapEditorRequestedEventArgs e)
    {
        if (DataContext
            is not DevicesViewModel viewModel)
        {
            return;
        }

        StopLiveDevicePolling();

        var window =
            new DeviceMapEditorWindow(
                e.DeviceProfile,
                e.ExistingMap,
                viewModel.ControlsViewModel,
                e.BaseDir)
            {
                Owner =
                    Window.GetWindow(this)
            };

        bool? result =
            window.ShowDialog();

        if (result == true)
        {
            viewModel.ReloadVisualMaps();
        }

        StartLiveDevicePolling();
    }

    private void DevicesViewModel_KeyMappingRequested(
        object? sender,
        DevicesKeyMappingRequestedEventArgs e)
    {
        if (DataContext
            is not DevicesViewModel viewModel)
        {
            return;
        }

        ControlsViewModel? controlsViewModel =
            viewModel.ControlsViewModel;

        if (controlsViewModel?.SelectedProfile
            is null)
        {
            return;
        }

        StopLiveDevicePolling();

        var window =
            new KeyMappingWindow
            {
                Owner =
                    Window.GetWindow(this)
            };

        window.DataContext =
            new KeyMappingWindowViewModel(
                e.Row,
                controlsViewModel.SelectedProfileRows,
                controlsViewModel.DeviceColumns,
                controlsViewModel
                    .SelectedProfile
                    .AircraftProfile,
                controlsViewModel
                    .ApplyKeyboardMappingFromPopup,
                controlsViewModel
                    .ApplyDeviceButtonMappingFromPopup,
                controlsViewModel
                    .ApplyDevicePovMappingFromPopup,
                () => window.Close());

        window.ShowDialog();

        // KeyMappingWindow saves through
        // ControlsViewModel. Refresh the Device
        // panel from that same in-memory model.
        viewModel.RefreshActiveMappedControlDetails();

        StartLiveDevicePolling();
    }
}