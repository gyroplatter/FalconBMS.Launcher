﻿using FalconBMS.Launcher.Models;
using FalconBMS.Launcher.Services;
using FalconBMS.Launcher.ViewModels;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using IOPath = System.IO.Path;

namespace FalconBMS.Launcher.Views;

public partial class DeviceMapEditorWindow : Window
{
    private enum CreationMode
    {
        None,
        PrimaryHotspot,
        SecondaryHotspot,
        Label
    }

    private enum DragMode
    {
        None,
        Hotspot,
        Label
    }

    private readonly DeviceBindingProfile
        _deviceProfile;

    private readonly ControlsViewModel?
        _controlsViewModel;

    private readonly string
        _baseDir;

    private readonly DeviceVisualMapService
        _visualMapService = new();

    private readonly LiveDeviceButtonStateService
        _deviceButtonPolling = new();

    private readonly DispatcherTimer
        _pollTimer;

    private DeviceVisualMap
        _map;

    private BitmapSource?
        _imageBitmap;

    private CreationMode
        _creationMode;

    private DragMode
        _dragMode;

    private Point
        _mouseDownPoint;

    private Point
        _dragStartPoint;

    private DeviceVisualHotspotMap?
        _dragHotspot;

    private DeviceVisualCalloutBoxMap?
        _dragCallout;

    private int
        _selectedHotspotIndex = -1;

    private bool
        _isDrawingHotspot;

    private DeviceVisualHotspotMap?
        _drawingHotspot;

    public ObservableCollection<DeviceMapEditorInputItem>
        InputItems
    { get; } = new();

    public DeviceMapEditorWindow(
        DeviceBindingProfile deviceProfile,
        DeviceVisualMap? existingMap,
        ControlsViewModel? controlsViewModel,
        string baseDir)
    {
        InitializeComponent();

        _deviceProfile = deviceProfile;
        _controlsViewModel = controlsViewModel;
        _baseDir = baseDir;

        _map =
            CloneMap(existingMap)
            ?? CreateEmptyMap(deviceProfile);

        DataContext = this;

        DeviceNameTextBlock.Text =
            GetDeviceDisplayName(deviceProfile);

        BuildInputList();
        LoadExistingImage();
        UpdateCurrentInputPanel();
        UpdateActionStates();

        _deviceButtonPolling.ButtonStateChanged +=
            DeviceButtonPolling_ButtonStateChanged;

        _pollTimer =
            new DispatcherTimer(
                DispatcherPriority.Background)
            {
                Interval =
                    TimeSpan.FromMilliseconds(30)
            };

        _pollTimer.Tick += PollTimer_Tick;

        Loaded +=
            DeviceMapEditorWindow_Loaded;

        Closed +=
            DeviceMapEditorWindow_Closed;
    }

    private void DeviceMapEditorWindow_Loaded(
        object? sender,
        RoutedEventArgs e)
    {
        _pollTimer.Start();
    }

    private void DeviceMapEditorWindow_Closed(
        object? sender,
        EventArgs e)
    {
        _pollTimer.Stop();

        _pollTimer.Tick -=
            PollTimer_Tick;

        _deviceButtonPolling.ButtonStateChanged -=
            DeviceButtonPolling_ButtonStateChanged;

        _deviceButtonPolling.Dispose();
    }

    private void PollTimer_Tick(
        object? sender,
        EventArgs e)
    {
        IntPtr hwnd =
            new WindowInteropHelper(this)
                .Handle;

        if (hwnd == IntPtr.Zero)
            return;

        _deviceButtonPolling.Poll(
            new[] { _deviceProfile },
            hwnd);
    }

    private void DeviceButtonPolling_ButtonStateChanged(
        object? sender,
        LiveDeviceButtonStateChangedEventArgs e)
    {
        if (!e.IsPressed)
            return;

        if (!string.Equals(
                e.DurableDeviceKey,
                _deviceProfile.DurableDeviceKey,
                StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        DeviceMapEditorInputItem? item =
            InputItems.FirstOrDefault(
                input =>
                    input.ButtonIndex
                    == e.ButtonIndex);

        if (item is null)
            return;

        Dispatcher.Invoke(
            () =>
                DeviceInputsListBox.SelectedItem =
                    item);
    }

    private void BuildInputList()
    {
        InputItems.Clear();

        for (int buttonIndex = 0;
             buttonIndex < _deviceProfile.ButtonCount;
             buttonIndex++)
        {
            string mappingText =
                ResolveBmsMapping(buttonIndex);

            InputItems.Add(
                new DeviceMapEditorInputItem(
                    buttonIndex,
                    "DX" + (buttonIndex + 1),
                    !string.Equals(
                        mappingText,
                        "Unassigned",
                        StringComparison.OrdinalIgnoreCase),
                    mappingText));
        }
    }

    private string ResolveBmsMapping(
        int buttonIndex)
    {
        string? aircraftProfileName =
            _controlsViewModel?
                .SelectedProfile?
                .AircraftProfile;

        DeviceAircraftBindingProfile?
            aircraftProfile =
                !string.IsNullOrWhiteSpace(
                    aircraftProfileName)
                    ? _deviceProfile
                        .AircraftProfiles
                        .FirstOrDefault(
                            profile =>
                                string.Equals(
                                    profile.AircraftProfile,
                                    aircraftProfileName,
                                    StringComparison.OrdinalIgnoreCase))
                    : _deviceProfile
                        .AircraftProfiles
                        .FirstOrDefault();

        DeviceButtonBinding? binding =
            aircraftProfile?
                .ButtonBindings
                .Where(
                    item =>
                        item.ButtonIndex
                            == buttonIndex
                        &&
                        !string.IsNullOrWhiteSpace(
                            item.CallbackName))
                .OrderBy(
                    item =>
                        item.AssignmentIndex)
                .FirstOrDefault();

        if (binding is null)
            return "Unassigned";

        BindingRow? row =
            _controlsViewModel?
                .SelectedProfileRows
                .FirstOrDefault(
                    item =>
                        item.IsEditable
                        &&
                        string.Equals(
                            item.CallbackName,
                            binding.CallbackName,
                            StringComparison.OrdinalIgnoreCase));

        string? description =
            row?.Description;

        if (!string.IsNullOrWhiteSpace(
                description))
        {
            return description!;
        }

        return binding.CallbackName
            ?? "Unassigned";
    }

    private void LoadExistingImage()
    {
        if (string.IsNullOrWhiteSpace(
                _map.RuntimeImagePath))
        {
            return;
        }

        try
        {
            BitmapSource bitmap =
                _visualMapService.LoadImage(
                    _map.RuntimeImagePath);

            SetImage(
                bitmap,
                IOPath.GetFileName(
                    _map.ImagePath));
        }
        catch (Exception ex)
        {
            DebugDiagnosticsService.Exception(
                ex,
                "Device map editor could not load the existing device image.");
        }
    }

    private void SelectImageButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        var dialog =
            new OpenFileDialog
            {
                Title =
                    "Select Device Image",

                Filter =
                    "Image files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All files (*.*)|*.*",

                CheckFileExists = true,
                Multiselect = false
            };

        if (dialog.ShowDialog(this)
            != true)
        {
            return;
        }

        if (_map.Controls.Count > 0)
        {
            MessageBoxResult result =
                MessageBox.Show(
                    this,
                    "Changing the image will clear the existing visual hotspots and labels for this device map. Continue?",
                    "Change Device Image",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

            if (result !=
                MessageBoxResult.Yes)
            {
                return;
            }

            _map.Controls.Clear();
            _map.CalloutBox = null;
        }

        try
        {
            BitmapSource bitmap =
                _visualMapService.LoadImage(
                    new Uri(
                        dialog.FileName,
                        UriKind.Absolute)
                    .AbsoluteUri);

            SetImage(
                bitmap,
                IOPath.GetFileName(
                    dialog.FileName));

            _map.ImagePath =
                IOPath.GetFileName(
                    dialog.FileName);

            RenderSelectedInput();
        }
        catch (Exception ex)
        {
            DebugDiagnosticsService.Exception(
                ex,
                "Device map editor image load failed.");

            MessageBox.Show(
                this,
                "The selected image could not be loaded.",
                "Device Map",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

     private void SetImage(
        BitmapSource bitmap,
        string? displayName)
    {
        _imageBitmap = bitmap;

        double canvasWidth =
            _map.CanvasWidth > 0
                ? _map.CanvasWidth
                : bitmap.PixelWidth;

        double canvasHeight =
            _map.CanvasHeight > 0
                ? _map.CanvasHeight
                : bitmap.PixelHeight;

        // A new image establishes its own map canvas.
        if (_map.Controls.Count == 0)
        {
            canvasWidth =
                bitmap.PixelWidth;

            canvasHeight =
                bitmap.PixelHeight;

            _map.CanvasWidth =
                canvasWidth;

            _map.CanvasHeight =
                canvasHeight;
        }

        MapCanvas.Width =
            canvasWidth;

        MapCanvas.Height =
            canvasHeight;

        DeviceImage.Width =
            canvasWidth;

        DeviceImage.Height =
            canvasHeight;

        DeviceImage.Source =
            bitmap;

        ImageNameTextBlock.Text =
            string.IsNullOrWhiteSpace(
                displayName)
                ? ""
                : displayName;

        SelectImageButton.Content =
            "Change Image";

        NoImageTextBlock.Visibility =
            Visibility.Collapsed;

        MapViewbox.Visibility =
            Visibility.Visible;

        RenderSelectedInput();
        UpdateActionStates();
    }

    private void DeviceInputsListBox_SelectionChanged(
        object sender,
        SelectionChangedEventArgs e)
    {
        CancelCreationMode();

        _selectedHotspotIndex = -1;

        UpdateCurrentInputPanel();
        RenderSelectedInput();
        UpdateActionStates();
    }

    private DeviceMapEditorInputItem?
        SelectedInput =>
            DeviceInputsListBox.SelectedItem
            as DeviceMapEditorInputItem;

    private DeviceVisualControlMap?
        SelectedControl =>
            SelectedInput is null
                ? null
                : _map.Controls
                    .FirstOrDefault(
                        control =>
                            string.Equals(
                                control.Kind,
                                "button",
                                StringComparison.OrdinalIgnoreCase)
                            &&
                            control.ButtonIndex
                                == SelectedInput.ButtonIndex);

    private void UpdateCurrentInputPanel()
    {
        DeviceMapEditorInputItem? input =
            SelectedInput;

        CurrentInputTextBlock.Text =
            input?.InputId
            ?? "None";

        CurrentMappingTextBlock.Text =
            input?.MappingText
            ?? "Press a button or select an input.";
    }

    private void UpdateActionStates()
    {
        DeviceVisualControlMap? control =
            SelectedControl;

        int hotspotCount =
            control?.Hotspots.Count
            ?? 0;

        bool hasImage =
            _imageBitmap is not null;

        bool hasInput =
            SelectedInput is not null;

        bool hasLabel =
            GetCalloutForControl(control)
            is not null;

        AddHotspotButton.IsEnabled =
            hasImage
            &&
            hasInput
            &&
            hotspotCount == 0;

        AddSecondaryHotspotButton.IsEnabled =
            hasImage
            &&
            hasInput
            &&
            hotspotCount == 1;

        ClearButton.IsEnabled =
            hasInput
            &&
            (
                hotspotCount > 0
                ||
                hasLabel
            );
    }

    private void AddHotspotButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        BeginHotspotCreation(
            CreationMode.PrimaryHotspot);
    }

    private void AddSecondaryHotspotButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        BeginHotspotCreation(
            CreationMode.SecondaryHotspot);
    }

    private void BeginHotspotCreation(
        CreationMode mode)
    {
        if (_imageBitmap is null
            ||
            SelectedInput is null)
        {
            return;
        }

        _creationMode = mode;

        MapCanvas.Cursor =
            Cursors.Cross;

        EditorInstructionTextBlock.Text =
            "Click and drag over the control on the image. Drag wider or taller to create an oval.";
    }

    private void PlaceLabelButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_imageBitmap is null
            ||
            SelectedControl is null)
        {
            return;
        }

        _creationMode =
            CreationMode.Label;

        MapCanvas.Cursor =
            Cursors.Cross;

        EditorInstructionTextBlock.Text =
            "Click the image where the label should appear. You can drag it afterward.";
    }

    private void ClearButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        DeviceMapEditorInputItem? input =
            SelectedInput;

        if (input is null)
            return;

        DeviceVisualControlMap? control =
            SelectedControl;

        if (control is not null)
        {
            // Clear removes only this input's
            // hotspot(s) and label.
            _map.Controls.Remove(control);
        }

        _selectedHotspotIndex = -1;

        CancelCreationMode();
        RenderSelectedInput();
        UpdateActionStates();
    }

    private void MapCanvas_PreviewMouseLeftButtonDown(
        object sender,
        MouseButtonEventArgs e)
    {
        if (_creationMode
                == CreationMode.None
            ||
            SelectedInput is null
            ||
            _imageBitmap is null)
        {
            return;
        }

        Point point =
            ClampPoint(
                e.GetPosition(MapCanvas));

        if (_creationMode
            == CreationMode.Label)
        {
            DeviceVisualControlMap control =
                GetOrCreateSelectedControl();

            double width =
                Math.Min(
                    260,
                    Math.Max(
                        180,
                        MapCanvas.Width * 0.22));

            control.CalloutBox =
                new DeviceVisualCalloutBoxMap
                {
                    X =
                        Clamp(
                            point.X,
                            0,
                            Math.Max(
                                0,
                                MapCanvas.Width
                                - width)),

                    Y =
                        Clamp(
                            point.Y,
                            0,
                            Math.Max(
                                0,
                                MapCanvas.Height
                                - 80)),

                    Width = width
                };

            _creationMode =
                CreationMode.None;

            MapCanvas.Cursor =
                Cursors.Arrow;

            EditorInstructionTextBlock.Text =
                "Drag the label to move it, or select another input.";

            RenderSelectedInput();
            UpdateActionStates();

            e.Handled = true;
            return;
        }

        _mouseDownPoint = point;

        _isDrawingHotspot = true;

        DeviceVisualControlMap
            selectedControl =
                GetOrCreateSelectedControl();

        _drawingHotspot =
            new DeviceVisualHotspotMap
            {
                Shape = "ellipse",

                X = point.X,
                Y = point.Y,

                Width = 1,
                Height = 1,

                AnchorX = point.X,
                AnchorY = point.Y
            };

        if (_creationMode
            == CreationMode.PrimaryHotspot)
        {
            selectedControl.Hotspots.Clear();
        }

        selectedControl.Hotspots.Add(
            _drawingHotspot);

        _selectedHotspotIndex =
            selectedControl.Hotspots.Count - 1;

        MapCanvas.CaptureMouse();

        RenderSelectedInput();

        e.Handled = true;
    }

    private void MapCanvas_PreviewMouseMove(
        object sender,
        MouseEventArgs e)
    {
        if (!_isDrawingHotspot
            ||
            _drawingHotspot is null
            ||
            e.LeftButton
                != MouseButtonState.Pressed)
        {
            return;
        }

        Point point =
            ClampPoint(
                e.GetPosition(MapCanvas));

        double deltaX =
            point.X
            - _mouseDownPoint.X;

        double deltaY =
            point.Y
            - _mouseDownPoint.Y;

        double left;
        double top;
        double width;
        double height;

        bool lockProportions =
            (Keyboard.Modifiers
             & ModifierKeys.Shift)
            == ModifierKeys.Shift;

        if (lockProportions)
        {
            // Shift constrains a newly drawn ellipse to a square,
            // which produces a perfect circle.
            double availableWidth =
                deltaX < 0
                    ? _mouseDownPoint.X
                    : MapCanvas.Width
                      - _mouseDownPoint.X;

            double availableHeight =
                deltaY < 0
                    ? _mouseDownPoint.Y
                    : MapCanvas.Height
                      - _mouseDownPoint.Y;

            double maximumSize =
                Math.Min(
                    availableWidth,
                    availableHeight);

            double size =
                Math.Min(
                    Math.Max(
                        4,
                        Math.Min(
                            Math.Abs(deltaX),
                            Math.Abs(deltaY))),
                    maximumSize);

            width = size;
            height = size;

            left =
                deltaX < 0
                    ? _mouseDownPoint.X - size
                    : _mouseDownPoint.X;

            top =
                deltaY < 0
                    ? _mouseDownPoint.Y - size
                    : _mouseDownPoint.Y;
        }
        else
        {
            left =
                Math.Min(
                    _mouseDownPoint.X,
                    point.X);

            top =
                Math.Min(
                    _mouseDownPoint.Y,
                    point.Y);

            width =
                Math.Max(
                    4,
                    Math.Abs(deltaX));

            height =
                Math.Max(
                    4,
                    Math.Abs(deltaY));
        }

        _drawingHotspot.X = left;
        _drawingHotspot.Y = top;
        _drawingHotspot.Width = width;
        _drawingHotspot.Height = height;

        UpdateHotspotAnchor(
            _drawingHotspot);

        RenderSelectedInput();

        e.Handled = true;
    }

    private void MapCanvas_PreviewMouseLeftButtonUp(
        object sender,
        MouseButtonEventArgs e)
    {
        if (!_isDrawingHotspot)
            return;

        _isDrawingHotspot = false;
        _drawingHotspot = null;
        _creationMode = CreationMode.None;

        MapCanvas.ReleaseMouseCapture();

        MapCanvas.Cursor =
            Cursors.Arrow;

        EditorInstructionTextBlock.Text =
            "Drag the hotspot to move it. Use the corner handles to resize it.";

        RenderSelectedInput();
        UpdateActionStates();

        e.Handled = true;
    }

    private void RenderSelectedInput()
    {
        RemoveMapOverlays();

        DeviceVisualControlMap? control =
            SelectedControl;

        if (control is null
            ||
            _imageBitmap is null)
        {
            return;
        }

        DeviceVisualCalloutBoxMap? callout =
            GetCalloutForControl(control);

        if (callout is not null)
        {
            foreach (
                DeviceVisualHotspotMap hotspot
                in control.Hotspots)
            {
                AddConnector(
                    hotspot,
                    callout);
            }
        }

        for (int index = 0;
             index < control.Hotspots.Count;
             index++)
        {
            AddHotspotVisual(
                control.Hotspots[index],
                index);
        }

        if (callout is not null)
        {
            AddLabelVisual(
                control,
                callout);
        }

        if (_selectedHotspotIndex >= 0
            &&
            _selectedHotspotIndex
                < control.Hotspots.Count)
        {
            AddResizeHandles(
                control.Hotspots[
                    _selectedHotspotIndex]);
        }
    }

    private void RemoveMapOverlays()
    {
        // Child zero is always the device image.
        while (MapCanvas.Children.Count > 1)
        {
            MapCanvas.Children.RemoveAt(
                MapCanvas.Children.Count - 1);
        }
    }

    private void AddHotspotVisual(
        DeviceVisualHotspotMap hotspot,
        int index)
    {
        var ellipse =
            new Ellipse
            {
                Width =
                    hotspot.Width,

                Height =
                    hotspot.Height,

                StrokeThickness =
                    index
                        == _selectedHotspotIndex
                        ? 3
                        : 2,

                Fill =
                    GetBrush(
                        "AppAccentBrush"),

                Opacity = 0.30,

                Tag = index,

                Cursor =
                    Cursors.SizeAll
            };

        ellipse.SetResourceReference(
            Shape.StrokeProperty,
            "AppAccentBrush");

        Canvas.SetLeft(
            ellipse,
            hotspot.X);

        Canvas.SetTop(
            ellipse,
            hotspot.Y);

        ellipse.MouseLeftButtonDown +=
            Hotspot_MouseLeftButtonDown;

        ellipse.MouseMove +=
            Hotspot_MouseMove;

        ellipse.MouseLeftButtonUp +=
            Hotspot_MouseLeftButtonUp;

        MapCanvas.Children.Add(
            ellipse);
    }

    private void Hotspot_MouseLeftButtonDown(
        object sender,
        MouseButtonEventArgs e)
    {
        if (_creationMode
                != CreationMode.None
            ||
            sender is not Ellipse ellipse
            ||
            ellipse.Tag is not int index)
        {
            return;
        }

        DeviceVisualControlMap? control =
            SelectedControl;

        if (control is null
            ||
            index < 0
            ||
            index >= control.Hotspots.Count)
        {
            return;
        }

        _selectedHotspotIndex = index;

        _dragHotspot =
            control.Hotspots[index];

        _dragMode =
            DragMode.Hotspot;

        _dragStartPoint =
            e.GetPosition(MapCanvas);

        ellipse.CaptureMouse();

        RenderSelectedInput();

        e.Handled = true;
    }

    private void Hotspot_MouseMove(
        object sender,
        MouseEventArgs e)
    {
        if (_dragMode
                != DragMode.Hotspot
            ||
            _dragHotspot is null
            ||
            e.LeftButton
                != MouseButtonState.Pressed)
        {
            return;
        }

        Point current =
            e.GetPosition(MapCanvas);

        double deltaX =
            current.X
            - _dragStartPoint.X;

        double deltaY =
            current.Y
            - _dragStartPoint.Y;

        _dragHotspot.X =
            Clamp(
                _dragHotspot.X
                + deltaX,
                0,
                Math.Max(
                    0,
                    MapCanvas.Width
                    - _dragHotspot.Width));

        _dragHotspot.Y =
            Clamp(
                _dragHotspot.Y
                + deltaY,
                0,
                Math.Max(
                    0,
                    MapCanvas.Height
                    - _dragHotspot.Height));

        UpdateHotspotAnchor(
            _dragHotspot);

        _dragStartPoint =
            current;

        RenderSelectedInput();

        e.Handled = true;
    }

    private void Hotspot_MouseLeftButtonUp(
        object sender,
        MouseButtonEventArgs e)
    {
        if (_dragMode
            != DragMode.Hotspot)
        {
            return;
        }

        if (sender
            is UIElement element)
        {
            element.ReleaseMouseCapture();
        }

        _dragMode =
            DragMode.None;

        _dragHotspot = null;

        RenderSelectedInput();

        e.Handled = true;
    }

    private void AddResizeHandles(
        DeviceVisualHotspotMap hotspot)
    {
        AddResizeHandle(
            hotspot,
            "TopLeft",
            hotspot.X,
            hotspot.Y);

        AddResizeHandle(
            hotspot,
            "TopRight",
            hotspot.X
                + hotspot.Width,
            hotspot.Y);

        AddResizeHandle(
            hotspot,
            "BottomLeft",
            hotspot.X,
            hotspot.Y
                + hotspot.Height);

        AddResizeHandle(
            hotspot,
            "BottomRight",
            hotspot.X
                + hotspot.Width,
            hotspot.Y
                + hotspot.Height);
    }

    private void AddResizeHandle(
        DeviceVisualHotspotMap hotspot,
        string corner,
        double centerX,
        double centerY)
    {
        const double size = 14;

        var thumb =
            new Thumb
            {
                Width = size,
                Height = size,

                Cursor =
                    corner == "TopLeft"
                    ||
                    corner == "BottomRight"
                        ? Cursors.SizeNWSE
                        : Cursors.SizeNESW,

                Tag =
                    new ResizeHandleTag(
                        hotspot,
                        corner)
            };

        thumb.SetResourceReference(
            Control.BackgroundProperty,
            "AppSurfaceBrush");

        thumb.SetResourceReference(
            Control.BorderBrushProperty,
            "AppAccentBrush");

        thumb.BorderThickness =
            new Thickness(2);

        thumb.DragDelta +=
            ResizeThumb_DragDelta;

        thumb.DragCompleted +=
            ResizeThumb_DragCompleted;

        Canvas.SetLeft(
            thumb,
            centerX - (size / 2));

        Canvas.SetTop(
            thumb,
            centerY - (size / 2));

        MapCanvas.Children.Add(
            thumb);
    }

    private void ResizeThumb_DragDelta(
        object sender,
        DragDeltaEventArgs e)
    {
        if (sender is not Thumb thumb
            ||
            thumb.Tag
                is not ResizeHandleTag tag)
        {
            return;
        }

        DeviceVisualHotspotMap hotspot =
            tag.Hotspot;

        const double minimumSize = 12;

        double left =
            hotspot.X;

        double top =
            hotspot.Y;

        double right =
            hotspot.X
            + hotspot.Width;

        double bottom =
            hotspot.Y
            + hotspot.Height;

        bool resizeFromLeft =
            tag.Corner.IndexOf(
                "Left",
                StringComparison.Ordinal) >= 0;

        bool resizeFromTop =
            tag.Corner.IndexOf(
                "Top",
                StringComparison.Ordinal) >= 0;

        bool lockProportions =
            (Keyboard.Modifiers
             & ModifierKeys.Shift)
            == ModifierKeys.Shift;

        if (lockProportions)
        {
            // Preserve the hotspot's current aspect ratio while Shift is held.
            // The corner opposite the dragged handle remains anchored.
            double horizontalSizeChange =
                resizeFromLeft
                    ? -e.HorizontalChange
                    : e.HorizontalChange;

            double verticalSizeChange =
                resizeFromTop
                    ? -e.VerticalChange
                    : e.VerticalChange;

            double horizontalScaleChange =
                horizontalSizeChange
                / hotspot.Width;

            double verticalScaleChange =
                verticalSizeChange
                / hotspot.Height;

            double requestedScale =
                1
                + (Math.Abs(horizontalScaleChange)
                   >= Math.Abs(verticalScaleChange)
                    ? horizontalScaleChange
                    : verticalScaleChange);

            double maximumWidth =
                resizeFromLeft
                    ? right
                    : MapCanvas.Width
                      - left;

            double maximumHeight =
                resizeFromTop
                    ? bottom
                    : MapCanvas.Height
                      - top;

            double minimumScale =
                Math.Max(
                    minimumSize
                    / hotspot.Width,

                    minimumSize
                    / hotspot.Height);

            double maximumScale =
                Math.Min(
                    maximumWidth
                    / hotspot.Width,

                    maximumHeight
                    / hotspot.Height);

            double scale =
                Clamp(
                    requestedScale,
                    minimumScale,
                    maximumScale);

            double newWidth =
                hotspot.Width
                * scale;

            double newHeight =
                hotspot.Height
                * scale;

            if (resizeFromLeft)
            {
                left =
                    right
                    - newWidth;
            }
            else
            {
                right =
                    left
                    + newWidth;
            }

            if (resizeFromTop)
            {
                top =
                    bottom
                    - newHeight;
            }
            else
            {
                bottom =
                    top
                    + newHeight;
            }
        }
        else
        {
            if (resizeFromLeft)
            {
                left =
                    Clamp(
                        left
                        + e.HorizontalChange,
                        0,
                        right
                        - minimumSize);
            }
            else
            {
                right =
                    Clamp(
                        right
                        + e.HorizontalChange,
                        left
                        + minimumSize,
                        MapCanvas.Width);
            }

            if (resizeFromTop)
            {
                top =
                    Clamp(
                        top
                        + e.VerticalChange,
                        0,
                        bottom
                        - minimumSize);
            }
            else
            {
                bottom =
                    Clamp(
                        bottom
                        + e.VerticalChange,
                        top
                        + minimumSize,
                        MapCanvas.Height);
            }
        }

        hotspot.X = left;
        hotspot.Y = top;
        hotspot.Width = right - left;
        hotspot.Height = bottom - top;

        UpdateHotspotAnchor(
            hotspot);

        UpdateHotspotResizeVisuals(
            hotspot);
    }

    private void UpdateHotspotResizeVisuals(
    DeviceVisualHotspotMap hotspot)
    {
        // Update the selected hotspot without rebuilding the Canvas
        foreach (UIElement child in MapCanvas.Children)
        {
            if (child is Ellipse ellipse
                &&
                ellipse.Tag is int index
                &&
                index == _selectedHotspotIndex)
            {
                ellipse.Width =
                    hotspot.Width;

                ellipse.Height =
                    hotspot.Height;

                Canvas.SetLeft(
                    ellipse,
                    hotspot.X);

                Canvas.SetTop(
                    ellipse,
                    hotspot.Y);

                continue;
            }

            if (child is not Thumb thumb
                ||
                thumb.Tag
                    is not ResizeHandleTag tag
                ||
                !ReferenceEquals(
                    tag.Hotspot,
                    hotspot))
            {
                continue;
            }

            double centerX;
            double centerY;

            switch (tag.Corner)
            {
                case "TopLeft":
                    centerX = hotspot.X;
                    centerY = hotspot.Y;
                    break;

                case "TopRight":
                    centerX =
                        hotspot.X
                        + hotspot.Width;

                    centerY =
                        hotspot.Y;
                    break;

                case "BottomLeft":
                    centerX =
                        hotspot.X;

                    centerY =
                        hotspot.Y
                        + hotspot.Height;
                    break;

                default:
                    centerX =
                        hotspot.X
                        + hotspot.Width;

                    centerY =
                        hotspot.Y
                        + hotspot.Height;
                    break;
            }

            Canvas.SetLeft(
                thumb,
                centerX
                - (thumb.Width / 2));

            Canvas.SetTop(
                thumb,
                centerY
                - (thumb.Height / 2));
        }
    }

    private void ResizeThumb_DragCompleted(
        object sender,
        DragCompletedEventArgs e)
    {
        RenderSelectedInput();
    }

    private void AddLabelVisual(
        DeviceVisualControlMap control,
        DeviceVisualCalloutBoxMap callout)
    {
        string mappingText =
            SelectedInput?.MappingText
            ?? "Unassigned";

        string inputId =
            SelectedInput?.InputId
            ?? control.InputId;

        var mappingTextBlock =
            new TextBlock
            {
                Text = mappingText,
                TextWrapping =
                    TextWrapping.Wrap
            };

        // Use the same text style as the Devices tab callout
        mappingTextBlock.SetResourceReference(
            FrameworkElement.StyleProperty,
            "DialogAssignmentValueStyle");

        var inputIdTextBlock =
            new TextBlock
            {
                Text = inputId,

                Margin =
                    new Thickness(
                        0,
                        4,
                        0,
                        0),

                TextWrapping =
                    TextWrapping.Wrap
            };

        // Use the same secondary text style as the Devices tab callout
        inputIdTextBlock.SetResourceReference(
            FrameworkElement.StyleProperty,
            "BodyTextBlockStyle");

        var panel =
            new StackPanel();

        panel.Children.Add(
            mappingTextBlock);

        panel.Children.Add(
            inputIdTextBlock);

        var border =
            new Border
            {
                Width =
                    callout.Width,

                Padding =
                    new Thickness(12),

                BorderThickness =
                    new Thickness(1),

                Child = panel,

                Cursor =
                    Cursors.SizeAll,

                Tag = callout,

                // The Devices tab scales the callout from its top left corner.
                // Do the same here so editor placement is the same.
                RenderTransformOrigin =
                    new Point(
                        0,
                        0),

                RenderTransform =
                    new ScaleTransform(
                        DeviceVisualCalloutViewModel.DefaultCalloutScale,
                        DeviceVisualCalloutViewModel.DefaultCalloutScale)
            };

        border.SetResourceReference(
            Border.BorderBrushProperty,
            "AppAccentBrush");

        border.SetResourceReference(
            Border.BackgroundProperty,
            "AppWindowBackgroundBrush");

        Canvas.SetLeft(
            border,
            callout.X);

        Canvas.SetTop(
            border,
            callout.Y);

        border.MouseLeftButtonDown +=
            Label_MouseLeftButtonDown;

        border.MouseMove +=
            Label_MouseMove;

        border.MouseLeftButtonUp +=
            Label_MouseLeftButtonUp;

        MapCanvas.Children.Add(
            border);
    }

    private void Label_MouseLeftButtonDown(
        object sender,
        MouseButtonEventArgs e)
    {
        if (_creationMode
                != CreationMode.None
            ||
            sender is not Border border
            ||
            border.Tag
                is not DeviceVisualCalloutBoxMap callout)
        {
            return;
        }

        DeviceVisualControlMap? control =
            SelectedControl;

        if (control is null)
            return;

        // Old built-in maps use one global callout.
        // As soon as this control is moved, give it its
        // own callout position.
        if (control.CalloutBox is null)
        {
            DeviceVisualCalloutBoxMap? clonedCallout =
                CloneCallout(callout);

            if (clonedCallout is null)
                return;

            control.CalloutBox =
                clonedCallout;

            callout =
                clonedCallout;

            border.Tag =
                callout;
        }

        _dragCallout =
            callout;

        _dragMode =
            DragMode.Label;

        _dragStartPoint =
            e.GetPosition(MapCanvas);

        border.CaptureMouse();

        e.Handled = true;
    }

    private void Label_MouseMove(
        object sender,
        MouseEventArgs e)
    {
        if (_dragMode
                != DragMode.Label
            ||
            _dragCallout is null
            ||
            e.LeftButton
                != MouseButtonState.Pressed)
        {
            return;
        }

        Point current =
            e.GetPosition(MapCanvas);

        double deltaX =
            current.X
            - _dragStartPoint.X;

        double deltaY =
            current.Y
            - _dragStartPoint.Y;

        _dragCallout.X =
            Clamp(
                _dragCallout.X
                + deltaX,
                0,
                Math.Max(
                    0,
                    MapCanvas.Width
                    - _dragCallout.Width));

        _dragCallout.Y =
            Clamp(
                _dragCallout.Y
                + deltaY,
                0,
                Math.Max(
                    0,
                    MapCanvas.Height
                    - 80));

        _dragStartPoint =
            current;

        RenderSelectedInput();

        e.Handled = true;
    }

    private void Label_MouseLeftButtonUp(
        object sender,
        MouseButtonEventArgs e)
    {
        if (_dragMode
            != DragMode.Label)
        {
            return;
        }

        if (sender
            is UIElement element)
        {
            element.ReleaseMouseCapture();
        }

        _dragMode =
            DragMode.None;

        _dragCallout = null;

        RenderSelectedInput();

        e.Handled = true;
    }

    private void AddConnector(
        DeviceVisualHotspotMap hotspot,
        DeviceVisualCalloutBoxMap callout)
    {
        double startX =
            hotspot.AnchorX;

        double startY =
            hotspot.AnchorY;

        double visualCalloutWidth =
            callout.Width
            * DeviceVisualCalloutViewModel.DefaultCalloutScale;

        double labelLeft =
            callout.X;

        double labelRight =
            callout.X
            + visualCalloutWidth;

        double targetX =
            startX < labelLeft
                ? labelLeft
                : startX > labelRight
                    ? labelRight
                    : callout.X
                      + (visualCalloutWidth / 2);

        // Match the Devices tab connector attachment point.
        double targetY =
            callout.Y + 48;

        double control1X =
            startX
            + ((targetX - startX) * 0.45);

        double control2X =
            startX
            + ((targetX - startX) * 0.65);

        var geometry =
            new PathGeometry();

        var figure =
            new PathFigure
            {
                StartPoint =
                    new Point(
                        startX,
                        startY)
            };

        figure.Segments.Add(
            new BezierSegment(
                new Point(
                    control1X,
                    startY),

                new Point(
                    control2X,
                    targetY),

                new Point(
                    targetX,
                    targetY),

                true));

        geometry.Figures.Add(
            figure);

        var path =
            new System.Windows.Shapes.Path
            {
                Data = geometry,
                StrokeThickness = 3,
                StrokeStartLineCap =
                    PenLineCap.Round,
                StrokeEndLineCap =
                    PenLineCap.Round,
                Opacity = 0.9,
                IsHitTestVisible = false
            };

        path.SetResourceReference(
            Shape.StrokeProperty,
            "AppAccentBrush");

        MapCanvas.Children.Add(
            path);
    }

    private DeviceVisualControlMap
        GetOrCreateSelectedControl()
    {
        DeviceMapEditorInputItem input =
            SelectedInput
            ?? throw new InvalidOperationException(
                "No device input is selected.");

        DeviceVisualControlMap? control =
            SelectedControl;

        if (control is not null)
            return control;

        control =
            new DeviceVisualControlMap
            {
                Kind = "button",

                ButtonIndex =
                    input.ButtonIndex,

                InputId =
                    input.InputId,

                // New maps intentionally do not need
                // a stored BMS/physical name.
                PhysicalName = ""
            };

        _map.Controls.Add(control);

        return control;
    }

    private DeviceVisualCalloutBoxMap?
        GetCalloutForControl(
            DeviceVisualControlMap? control)
    {
        if (control is null)
            return null;

        return control.CalloutBox
               ?? _map.CalloutBox;
    }

    private void CancelCreationMode()
    {
        _creationMode =
            CreationMode.None;

        _isDrawingHotspot =
            false;

        _drawingHotspot =
            null;

        MapCanvas.ReleaseMouseCapture();

        MapCanvas.Cursor =
            Cursors.Arrow;

        EditorInstructionTextBlock.Text =
            "Press a button on the device or select an input on the left.";
    }

    private void SaveMapButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_imageBitmap is null)
        {
            MessageBox.Show(
                this,
                "Select an image before saving the device map.",
                "Device Map",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return;
        }

        _map.CanvasWidth =
            MapCanvas.Width;

        _map.CanvasHeight =
            MapCanvas.Height;

        try
        {
            _visualMapService.SaveUserMap(
                _baseDir,
                _deviceProfile,
                _map,
                _imageBitmap);

            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            DebugDiagnosticsService.Exception(
                ex,
                "Device map save failed.");

            MessageBox.Show(
                this,
                "The device map could not be saved.",
                "Device Map",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    private void CancelButton_Click(
        object sender,
        RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }

    private Brush GetBrush(
        string resourceKey)
    {
        return TryFindResource(resourceKey)
               as Brush
               ?? Brushes.Transparent;
    }

    private Point ClampPoint(
        Point point)
    {
        return new Point(
            Clamp(
                point.X,
                0,
                MapCanvas.Width),

            Clamp(
                point.Y,
                0,
                MapCanvas.Height));
    }

    private static void UpdateHotspotAnchor(
        DeviceVisualHotspotMap hotspot)
    {
        hotspot.AnchorX =
            hotspot.X
            + (hotspot.Width / 2);

        hotspot.AnchorY =
            hotspot.Y
            + (hotspot.Height / 2);
    }

    private static double Clamp(
        double value,
        double minimum,
        double maximum)
    {
        if (maximum < minimum)
            maximum = minimum;

        return Math.Max(
            minimum,
            Math.Min(
                maximum,
                value));
    }

    private static DeviceVisualMap CreateEmptyMap(
        DeviceBindingProfile deviceProfile)
    {
        return new DeviceVisualMap
        {
            StockDeviceName =
                GetDeviceDisplayName(
                    deviceProfile),

            Controls =
                new List<DeviceVisualControlMap>()
        };
    }

    private static DeviceVisualMap?
        CloneMap(
            DeviceVisualMap? source)
    {
        if (source is null)
            return null;

        return new DeviceVisualMap
        {
            StockDeviceName =
                source.StockDeviceName,

            ImagePath =
                source.ImagePath,

            RuntimeImagePath =
                source.RuntimeImagePath,

            CanvasWidth =
                source.CanvasWidth,

            CanvasHeight =
                source.CanvasHeight,

            CalloutBox =
                CloneCallout(
                    source.CalloutBox),

            Controls =
                source.Controls
                    .Select(
                        control =>
                            new DeviceVisualControlMap
                            {
                                Kind =
                                    control.Kind,

                                ButtonIndex =
                                    control.ButtonIndex,

                                InputId =
                                    control.InputId,

                                PhysicalName =
                                    control.PhysicalName,

                                CalloutBox =
                                    CloneCallout(
                                        control.CalloutBox),

                                Hotspots =
                                    control.Hotspots
                                        .Select(
                                            hotspot =>
                                                new DeviceVisualHotspotMap
                                                {
                                                    Shape =
                                                        hotspot.Shape,

                                                    X =
                                                        hotspot.X,

                                                    Y =
                                                        hotspot.Y,

                                                    Width =
                                                        hotspot.Width,

                                                    Height =
                                                        hotspot.Height,

                                                    AnchorX =
                                                        hotspot.AnchorX,

                                                    AnchorY =
                                                        hotspot.AnchorY
                                                })
                                        .ToList()
                            })
                    .ToList()
        };
    }

    private static DeviceVisualCalloutBoxMap?
        CloneCallout(
            DeviceVisualCalloutBoxMap? source)
    {
        if (source is null)
            return null;

        return new DeviceVisualCalloutBoxMap
        {
            X = source.X,
            Y = source.Y,
            Width = source.Width
        };
    }

    private static string GetDeviceDisplayName(
        DeviceBindingProfile deviceProfile)
    {
        if (!string.IsNullOrWhiteSpace(
                deviceProfile.ProductName))
        {
            return deviceProfile.ProductName;
        }

        if (!string.IsNullOrWhiteSpace(
                deviceProfile.InstanceName))
        {
            return deviceProfile.InstanceName;
        }

        return deviceProfile.DurableDeviceKey;
    }

    private sealed class ResizeHandleTag
    {
        public DeviceVisualHotspotMap
            Hotspot
        { get; }

        public string
            Corner
        { get; }

        public ResizeHandleTag(
            DeviceVisualHotspotMap hotspot,
            string corner)
        {
            Hotspot = hotspot;
            Corner = corner;
        }
    }
}

public sealed class DeviceMapEditorInputItem
{
    public int ButtonIndex { get; }

    public string InputId { get; }

    public bool HasBmsMapping { get; }

    public string MappingText { get; }

    public DeviceMapEditorInputItem(
        int buttonIndex,
        string inputId,
        bool hasBmsMapping,
        string mappingText)
    {
        ButtonIndex = buttonIndex;
        InputId = inputId;
        HasBmsMapping = hasBmsMapping;
        MappingText = mappingText;
    }

    public override string ToString()
    {
        return InputId;
    }
}