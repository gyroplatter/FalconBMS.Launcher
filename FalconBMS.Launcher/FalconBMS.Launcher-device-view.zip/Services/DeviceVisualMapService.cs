﻿using FalconBMS.Launcher.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;

namespace FalconBMS.Launcher.Services;

/// <summary>
/// Loads built-in and user created visual device maps.
/// User maps live under User\Config\DeviceMaps and override built-in maps that
/// use the same stock device name.
/// </summary>
public sealed class DeviceVisualMapService
{
    private const string DeviceMapPackageFilter =
        "Launcher device map (*.zip)|*.zip";

    private static readonly string[] BuiltInMapResourcePaths =
    {
        "Assets/Devices/Joystick - HOTAS Warthog.map.json",
        "Assets/Devices/F16 MFD 1.map.json",
        "Assets/Devices/F16 MFD 2.map.json"
    };

    public IReadOnlyList<DeviceVisualMap> LoadMaps(string? baseDir)
    {
        var mapsByDeviceName =
            new Dictionary<string, DeviceVisualMap>(
                StringComparer.OrdinalIgnoreCase);

        foreach (string resourcePath in BuiltInMapResourcePaths)
        {
            try
            {
                DeviceVisualMap? map =
                    LoadBuiltInMap(resourcePath);

                if (map is not null &&
                    !string.IsNullOrWhiteSpace(map.StockDeviceName))
                {
                    mapsByDeviceName[map.StockDeviceName] = map;
                }
            }
            catch (Exception ex)
            {
                DebugDiagnosticsService.Exception(
                    ex,
                    $"Device visual map load failed: {resourcePath}");
            }
        }

        if (!string.IsNullOrWhiteSpace(baseDir))
        {
            string userMapsDirectory =
                GetUserMapsDirectory(baseDir!);

            if (Directory.Exists(userMapsDirectory))
            {
                foreach (string mapPath in
                         Directory.EnumerateFiles(
                             userMapsDirectory,
                             "*.map.json",
                             SearchOption.AllDirectories))
                {
                    try
                    {
                        DeviceVisualMap? map =
                            LoadFileMap(mapPath);

                        if (map is not null &&
                            !string.IsNullOrWhiteSpace(
                                map.StockDeviceName))
                        {
                            // User maps intentionally override
                            // built-in maps for the same device.
                            mapsByDeviceName[map.StockDeviceName] =
                                map;
                        }
                    }
                    catch (Exception ex)
                    {
                        DebugDiagnosticsService.Exception(
                            ex,
                            $"User device visual map load failed: {mapPath}");
                    }
                }
            }
        }

        return mapsByDeviceName.Values.ToList();
    }

    public DeviceVisualMap? FindMapForDevice(
        DeviceBindingProfile deviceProfile,
        IReadOnlyList<DeviceVisualMap> maps)
    {
        return maps.FirstOrDefault(
            map =>
                string.Equals(
                    map.StockDeviceName,
                    deviceProfile.ProductName,
                    StringComparison.OrdinalIgnoreCase)
                ||
                string.Equals(
                    map.StockDeviceName,
                    deviceProfile.InstanceName,
                    StringComparison.OrdinalIgnoreCase));
    }

    public BitmapSource LoadImage(
    string imageSource)
    {
        var bitmap =
            new BitmapImage();

        bitmap.BeginInit();

        // Load the image into memory so displaying it does not
        // keep the source PNG locked on disk
        bitmap.CacheOption =
            BitmapCacheOption.OnLoad;

        bitmap.CreateOptions =
            BitmapCreateOptions.IgnoreImageCache;

        bitmap.UriSource =
            new Uri(
                imageSource,
                UriKind.Absolute);

        bitmap.EndInit();
        bitmap.Freeze();

        return bitmap;
    }

    public string SaveUserMap(
        string baseDir,
        DeviceBindingProfile deviceProfile,
        DeviceVisualMap map,
        BitmapSource image)
    {
        string deviceName =
            GetDeviceDisplayName(deviceProfile);

        string deviceDirectory =
            Path.Combine(
                GetUserMapsDirectory(baseDir),
                MakeSafeFileName(deviceName));

        Directory.CreateDirectory(deviceDirectory);

        string imageFileName =
            MakeSafeFileName(deviceName) + ".png";

        string targetImagePath =
            Path.Combine(
                deviceDirectory,
                imageFileName);

        // User maps always save a local PNG copy so the map remains
        // self-contained even if the original selected image later moves
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(
            BitmapFrame.Create(image));

        using (FileStream imageStream =
               File.Create(targetImagePath))
        {
            encoder.Save(imageStream);
        }

        map.StockDeviceName = deviceName;
        map.ImagePath = imageFileName;
        map.RuntimeImagePath =
            new Uri(
                targetImagePath,
                UriKind.Absolute)
            .AbsoluteUri;

        string mapPath =
            Path.Combine(
                deviceDirectory,
                MakeSafeFileName(deviceName)
                + ".map.json");

        WriteMapFile(
            mapPath,
            map);

        return mapPath;
    }

    private static string SaveImportedMap(
    string baseDir,
    DeviceBindingProfile deviceProfile,
    DeviceVisualMap map,
    Stream imageStream)
    {
        string deviceName =
            GetDeviceDisplayName(
                deviceProfile);

        string safeDeviceName =
            MakeSafeFileName(
                deviceName);

        string deviceDirectory =
            Path.Combine(
                GetUserMapsDirectory(baseDir),
                safeDeviceName);

        Directory.CreateDirectory(
            deviceDirectory);

        string imageFileName =
            safeDeviceName
            + ".png";

        string targetImagePath =
            Path.Combine(
                deviceDirectory,
                imageFileName);

        // Imported package already contains the canonical PNG.
        // Copy those exact bytes instead of decoding and re-encoding it.
        using (FileStream targetImageStream =
               File.Create(
                   targetImagePath))
        {
            imageStream.CopyTo(
                targetImageStream);
        }

        map.StockDeviceName =
            deviceName;

        map.ImagePath =
            imageFileName;

        map.RuntimeImagePath =
            new Uri(
                targetImagePath,
                UriKind.Absolute)
            .AbsoluteUri;

        string mapPath =
            Path.Combine(
                deviceDirectory,
                safeDeviceName
                + ".map.json");

        WriteMapFile(
            mapPath,
            map);

        return mapPath;
    }

    public bool ImportMapPackage(
    string baseDir,
    DeviceBindingProfile deviceProfile,
    Window? owner)
    {
        var openDialog = new OpenFileDialog
        {
            Title = "Import Map",
            Filter = DeviceMapPackageFilter,
            CheckFileExists = true,
            Multiselect = false
        };

        if (openDialog.ShowDialog(owner) != true)
            return false;

        try
        {
            using FileStream packageStream =
                File.OpenRead(
                    openDialog.FileName);

            using var archive =
                new ZipArchive(
                    packageStream,
                    ZipArchiveMode.Read,
                    leaveOpen: false);

            ZipArchiveEntry[] mapEntries =
                archive.Entries
                    .Where(entry =>
                        entry.FullName.EndsWith(
                            ".map.json",
                            StringComparison.OrdinalIgnoreCase))
                    .ToArray();

            if (mapEntries.Length != 1)
            {
                throw new InvalidDataException(
                    "The map package must contain exactly one .map.json file.");
            }

            DeviceVisualMap? map;

            using (Stream mapStream =
                   mapEntries[0].Open())
            {
                map = DeserializeMap(
                    mapStream);
            }

            if (map is null)
            {
                throw new InvalidDataException(
                    "The map JSON could not be read.");
            }

            string imageFileName =
                Path.GetFileName(
                    map.ImagePath);

            if (string.IsNullOrWhiteSpace(
                    imageFileName))
            {
                throw new InvalidDataException(
                    "The map JSON does not identify an image file.");
            }

            if (!string.Equals(
                    Path.GetExtension(
                        imageFileName),
                    ".png",
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException(
                    "The map package image must be a PNG file.");
            }

            ZipArchiveEntry? imageEntry =
                archive.Entries
                    .FirstOrDefault(entry =>
                        string.Equals(
                            Path.GetFileName(
                                entry.FullName),
                            imageFileName,
                            StringComparison.OrdinalIgnoreCase));

            if (imageEntry is null)
            {
                throw new InvalidDataException(
                    "The map package does not contain its referenced image file.");
            }

            if (imageEntry.Length <= 0)
            {
                throw new InvalidDataException(
                    "The map package image is empty.");
            }

            string savedMapPath;

            using (Stream imageStream =
                   imageEntry.Open())
            {
                savedMapPath =
                    SaveImportedMap(
                        baseDir,
                        deviceProfile,
                        map,
                        imageStream);
            }

            DebugDiagnosticsService.Info(
                $"Device visual map imported | Device=\"{GetDeviceDisplayName(deviceProfile)}\" | Source=\"{openDialog.FileName}\" | Destination=\"{savedMapPath}\"");

            MessageBox.Show(
                owner,
                "Imported map for:\n\n"
                + GetDeviceDisplayName(
                    deviceProfile),
                "Import Map",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            return true;
        }
        catch (Exception ex)
        {
            DebugDiagnosticsService.Exception(
                ex,
                $"Device visual map import failed: {openDialog.FileName}");

            MessageBox.Show(
                owner,
                "The selected map could not be imported.\n\n"
                + ex.Message,
                "Import Map",
                MessageBoxButton.OK,
                MessageBoxImage.Error);

            return false;
        }
    }

    public void ExportMapPackage(
        DeviceBindingProfile deviceProfile,
        DeviceVisualMap map,
        Window? owner)
    {
        string deviceName =
            GetDeviceDisplayName(
                deviceProfile);

        string safeDeviceName =
            MakeSafeFileName(
                deviceName);

        var saveDialog = new SaveFileDialog
        {
            Title = "Export Map",
            Filter = DeviceMapPackageFilter,
            FileName =
                safeDeviceName
                + ".device-map.zip",
            OverwritePrompt = true
        };

        if (saveDialog.ShowDialog(owner) != true)
            return;

        try
        {
            if (string.IsNullOrWhiteSpace(
                    map.RuntimeImagePath))
            {
                throw new InvalidDataException(
                    "The current map does not have an image source.");
            }

            DeviceVisualMap exportMap =
                CloneMapForExport(
                    map);

            string imageFileName =
                safeDeviceName
                + ".png";

            exportMap.StockDeviceName =
                deviceName;

            exportMap.ImagePath =
                imageFileName;

            exportMap.RuntimeImagePath =
                "";

            using FileStream packageStream =
                File.Create(
                    saveDialog.FileName);

            using var archive =
                new ZipArchive(
                    packageStream,
                    ZipArchiveMode.Create,
                    leaveOpen: false);

            ZipArchiveEntry mapEntry =
                archive.CreateEntry(
                    safeDeviceName
                    + ".map.json",
                    CompressionLevel.Optimal);

            using (Stream mapStream =
                   mapEntry.Open())
            {
                WriteMap(
                    mapStream,
                    exportMap);
            }

            ZipArchiveEntry imageEntry =
                archive.CreateEntry(
                    imageFileName,
                    CompressionLevel.Optimal);

            using (Stream imageStream =
                   imageEntry.Open())
            {
                CopyRuntimeImageToStream(
                    map.RuntimeImagePath,
                    imageStream);
            }

            DebugDiagnosticsService.Info(
                $"Device visual map exported | Device=\"{deviceName}\" | Destination=\"{saveDialog.FileName}\"");

            MessageBox.Show(
                owner,
                "Exported map for:\n\n"
                + deviceName,
                "Export Map",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            DebugDiagnosticsService.Exception(
                ex,
                $"Device visual map export failed: {saveDialog.FileName}");

            MessageBox.Show(
                owner,
                "The current map could not be exported.\n\n"
                + ex.Message,
                "Export Map",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }

    public static string GetUserMapsDirectory(
        string baseDir)
    {
        return Path.Combine(
            baseDir,
            "User",
            "Config",
            "DeviceMaps");
    }

    private static DeviceVisualMap?
        LoadBuiltInMap(
            string resourcePath)
    {
        string normalizedPath =
            resourcePath.Replace('\\', '/');

        string escapedPath =
            string.Join(
                "/",
                normalizedPath
                    .Split('/')
                    .Select(Uri.EscapeDataString));

        var uri =
            new Uri(
                $"pack://application:,,,/{escapedPath}",
                UriKind.Absolute);

        var resource =
            Application.GetResourceStream(uri);

        if (resource is null)
            return null;

        using var stream =
            resource.Stream;

        DeviceVisualMap? map =
            DeserializeMap(stream);

        if (map is not null)
        {
            map.RuntimeImagePath =
                BuildPackUri(map.ImagePath);
        }

        return map;
    }

    private static DeviceVisualMap?
        LoadFileMap(
            string mapPath)
    {
        using var stream =
            File.OpenRead(mapPath);

        DeviceVisualMap? map =
            DeserializeMap(stream);

        if (map is null)
            return null;

        string mapDirectory =
            Path.GetDirectoryName(mapPath)
            ?? "";

        string imagePath =
            Path.IsPathRooted(map.ImagePath)
                ? map.ImagePath
                : Path.Combine(
                    mapDirectory,
                    map.ImagePath);

        if (!File.Exists(imagePath))
            return null;

        map.RuntimeImagePath =
            new Uri(
                imagePath,
                UriKind.Absolute)
            .AbsoluteUri;

        return map;
    }

    private static DeviceVisualMap?
        DeserializeMap(
            Stream stream)
    {
        using var reader =
            new StreamReader(
                stream,
                Encoding.UTF8,
                detectEncodingFromByteOrderMarks: true,
                bufferSize: 1024,
                leaveOpen: true);

        string json =
            reader
                .ReadToEnd()
                .TrimStart('\uFEFF');

        using var jsonStream =
            new MemoryStream(
                Encoding.UTF8.GetBytes(json));

        var serializer =
            new DataContractJsonSerializer(
                typeof(DeviceVisualMap));

        return serializer.ReadObject(jsonStream)
            as DeviceVisualMap;
    }

    private static void WriteMapFile(
        string mapPath,
        DeviceVisualMap map)
    {
        using var stream =
            new MemoryStream();

        WriteMap(
            stream,
            map);

        string json =
            Encoding.UTF8.GetString(
                stream.ToArray());

        File.WriteAllText(
            mapPath,
            json,
            new UTF8Encoding(
                encoderShouldEmitUTF8Identifier: false));
    }

    private static void WriteMap(
        Stream stream,
        DeviceVisualMap map)
    {
        var settings =
            new DataContractJsonSerializerSettings
            {
                UseSimpleDictionaryFormat = true
            };

        var serializer =
            new DataContractJsonSerializer(
                typeof(DeviceVisualMap),
                settings);

        serializer.WriteObject(
            stream,
            map);
    }

    private static DeviceVisualMap CloneMapForExport(
        DeviceVisualMap map)
    {
        using var stream =
            new MemoryStream();

        WriteMap(
            stream,
            map);

        stream.Position = 0;

        return DeserializeMap(
                   stream)
               ?? throw new InvalidDataException(
                   "The current map could not be prepared for export.");
    }

    private static void CopyRuntimeImageToStream(
    string runtimeImagePath,
    Stream destination)
    {
        var imageUri =
            new Uri(
                runtimeImagePath,
                UriKind.Absolute);

        // User-created maps use a normal file URI.
        if (imageUri.IsFile)
        {
            using FileStream source =
                File.OpenRead(
                    imageUri.LocalPath);

            source.CopyTo(
                destination);

            return;
        }

        // Built-in maps use an embedded WPF pack resource.
        if (string.Equals(
                imageUri.Scheme,
                "pack",
                StringComparison.OrdinalIgnoreCase))
        {
            var resource =
                Application.GetResourceStream(
                    imageUri);

            if (resource is null)
            {
                throw new FileNotFoundException(
                    "The built-in device map image could not be found.",
                    runtimeImagePath);
            }

            using Stream source =
                resource.Stream;

            source.CopyTo(
                destination);

            return;
        }

        throw new NotSupportedException(
            "The current device map image source is not supported.");
    }

    private static string BuildPackUri(
        string resourcePath)
    {
        string normalizedPath =
            resourcePath.Replace('\\', '/');

        string escapedPath =
            string.Join(
                "/",
                normalizedPath
                    .Split('/')
                    .Select(Uri.EscapeDataString));

        return
            $"pack://application:,,,/{escapedPath}";
    }

    private static string GetDeviceDisplayName(
        DeviceBindingProfile deviceProfile)
    {
        if (!string.IsNullOrWhiteSpace(
                deviceProfile.ProductName))
        {
            return deviceProfile.ProductName;
        }

        if (!string.IsNullOrWhiteSpace(
                deviceProfile.InstanceName))
        {
            return deviceProfile.InstanceName;
        }

        return deviceProfile.DurableDeviceKey;
    }

    private static string MakeSafeFileName(
        string value)
    {
        char[] invalidChars =
            Path.GetInvalidFileNameChars();

        var builder =
            new StringBuilder(value.Length);

        foreach (char character in value)
        {
            builder.Append(
                invalidChars.Contains(character)
                    ? '_'
                    : character);
        }

        string safe =
            builder.ToString().Trim();

        return string.IsNullOrWhiteSpace(safe)
            ? "Device"
            : safe;
    }
}