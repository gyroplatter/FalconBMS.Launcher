﻿namespace FalconBMS.Launcher.Models;

/// <summary>
/// Enum for the Launcher's main navigation tabs.
/// </summary>
public enum LauncherTab
{
    Main = 0,
    Controls = 1,
    Devices = 2,
    Display = 3,
    Views = 4,
    Styles = 5,
}